"""
Professional PDF Invoice Generator using ReportLab.
Supports CSV or dict input, batch export, auto-numbering, logo, and tax calculation.
"""

import csv
import os
from datetime import date, datetime
from pathlib import Path
from typing import Union

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    HRFlowable,
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------
PRIMARY = colors.HexColor("#1A237E")   # dark indigo
ACCENT = colors.HexColor("#3949AB")    # medium indigo
LIGHT_BG = colors.HexColor("#E8EAF6")  # very light indigo
WHITE = colors.white
GRAY_TEXT = colors.HexColor("#555555")
BORDER_GRAY = colors.HexColor("#CCCCCC")

PAGE_W, PAGE_H = A4
MARGIN = 18 * mm


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _money(value: float, symbol: str = "$") -> str:
    return f"{symbol}{value:,.2f}"


def _read_csv(path: str) -> list[dict]:
    """Return a list of invoice dicts from a CSV file."""
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return [row for row in reader]


def _next_invoice_number(output_dir: str, prefix: str = "INV") -> str:
    """Auto-increment invoice number based on existing PDFs in output_dir."""
    existing = list(Path(output_dir).glob(f"{prefix}-*.pdf"))
    numbers = []
    for p in existing:
        stem = p.stem  # e.g. INV-00042
        try:
            numbers.append(int(stem.split("-")[-1]))
        except ValueError:
            pass
    next_num = (max(numbers) + 1) if numbers else 1
    return f"{prefix}-{next_num:05d}"


# ---------------------------------------------------------------------------
# Core builder
# ---------------------------------------------------------------------------

class InvoiceGenerator:
    """
    Generates a professional PDF invoice from a data dict.

    Required keys in `data`:
        company_name, company_address, company_email, company_phone
        client_name, client_address, client_email
        items: list of dicts with keys: description, quantity, unit_price
        tax_rate: float (e.g. 0.10 for 10%)

    Optional keys:
        invoice_number (auto-generated if absent)
        invoice_date   (today if absent)
        due_date
        logo_path
        currency_symbol (default "$")
        notes
    """

    def __init__(self, output_dir: str = "output"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self._styles = getSampleStyleSheet()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(self, data: dict) -> str:
        """Generate a single PDF invoice. Returns the output file path."""
        inv_num = data.get("invoice_number") or _next_invoice_number(
            self.output_dir, data.get("prefix", "INV")
        )
        data["invoice_number"] = inv_num
        filename = os.path.join(self.output_dir, f"{inv_num}.pdf")
        self._build_pdf(data, filename)
        return filename

    def generate_batch_from_dicts(self, invoices: list[dict]) -> list[str]:
        """Generate multiple PDFs from a list of data dicts."""
        return [self.generate(inv) for inv in invoices]

    def generate_batch_from_csv(self, csv_path: str, items_csv_path: str) -> list[str]:
        """
        Generate PDFs from two CSV files:
          - csv_path: one row per invoice (header/client info + tax_rate)
          - items_csv_path: line items with an 'invoice_id' column linking to csv_path 'id'
        """
        invoices_raw = _read_csv(csv_path)
        items_raw = _read_csv(items_csv_path)

        # Group items by invoice id
        items_by_id: dict[str, list[dict]] = {}
        for item in items_raw:
            iid = item["invoice_id"]
            items_by_id.setdefault(iid, []).append({
                "description": item["description"],
                "quantity": float(item["quantity"]),
                "unit_price": float(item["unit_price"]),
            })

        invoices = []
        for row in invoices_raw:
            iid = row["id"]
            inv = {
                "invoice_number": row.get("invoice_number") or None,
                "invoice_date": row.get("invoice_date") or str(date.today()),
                "due_date": row.get("due_date", ""),
                "company_name": row["company_name"],
                "company_address": row["company_address"],
                "company_email": row["company_email"],
                "company_phone": row.get("company_phone", ""),
                "client_name": row["client_name"],
                "client_address": row["client_address"],
                "client_email": row["client_email"],
                "tax_rate": float(row.get("tax_rate", 0)),
                "currency_symbol": row.get("currency_symbol", "$"),
                "notes": row.get("notes", ""),
                "logo_path": row.get("logo_path", ""),
                "items": items_by_id.get(iid, []),
            }
            invoices.append(inv)

        return self.generate_batch_from_dicts(invoices)

    # ------------------------------------------------------------------
    # PDF construction
    # ------------------------------------------------------------------

    def _build_pdf(self, data: dict, filename: str) -> None:
        doc = SimpleDocTemplate(
            filename,
            pagesize=A4,
            leftMargin=MARGIN,
            rightMargin=MARGIN,
            topMargin=MARGIN,
            bottomMargin=MARGIN,
        )
        story = []
        story += self._header_section(data)
        story.append(Spacer(1, 6 * mm))
        story += self._billing_section(data)
        story.append(Spacer(1, 8 * mm))
        story += self._items_table(data)
        story.append(Spacer(1, 6 * mm))
        story += self._totals_section(data)
        if data.get("notes"):
            story.append(Spacer(1, 8 * mm))
            story += self._notes_section(data["notes"])
        story += self._footer_section(data)
        doc.build(story)

    # ------------------------------------------------------------------
    # Sections
    # ------------------------------------------------------------------

    def _header_section(self, data: dict) -> list:
        sym = data.get("currency_symbol", "$")
        content_width = PAGE_W - 2 * MARGIN

        # Left: logo or company name block
        logo_path = data.get("logo_path", "")
        if logo_path and os.path.isfile(logo_path):
            logo = Image(logo_path, width=40 * mm, height=20 * mm, kind="proportional")
            left_cell = logo
        else:
            left_cell = Paragraph(
                f'<font color="#1A237E"><b>{data["company_name"]}</b></font>',
                ParagraphStyle("CompanyBig", fontSize=18, leading=22,
                               textColor=PRIMARY, fontName="Helvetica-Bold"),
            )

        # Right: INVOICE title + number/date
        inv_date = data.get("invoice_date") or str(date.today())
        due_date = data.get("due_date", "")
        right_lines = (
            f'<font color="#1A237E" size="22"><b>INVOICE</b></font><br/>'
            f'<font color="#555555" size="9">'
            f'<b>Invoice #:</b> {data["invoice_number"]}<br/>'
            f'<b>Date:</b> {inv_date}<br/>'
            + (f'<b>Due:</b> {due_date}<br/>' if due_date else "")
            + "</font>"
        )
        right_cell = Paragraph(right_lines,
                               ParagraphStyle("InvTitle", alignment=TA_RIGHT,
                                              leading=16, fontSize=9))

        header_table = Table(
            [[left_cell, right_cell]],
            colWidths=[content_width * 0.55, content_width * 0.45],
        )
        header_table.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ]))

        return [
            header_table,
            Spacer(1, 3 * mm),
            HRFlowable(width="100%", thickness=2, color=PRIMARY),
        ]

    def _billing_section(self, data: dict) -> list:
        content_width = PAGE_W - 2 * MARGIN
        label_style = ParagraphStyle("BillLabel", fontSize=8, textColor=WHITE,
                                     fontName="Helvetica-Bold", leading=12,
                                     spaceAfter=2)
        value_style = ParagraphStyle("BillValue", fontSize=9, textColor=GRAY_TEXT,
                                     leading=13)

        def _block(label: str, lines: list[str]) -> list:
            return [
                Paragraph(label, label_style),
                *[Paragraph(line, value_style) for line in lines],
            ]

        from_lines = [
            data["company_name"],
            data["company_address"],
            data["company_email"],
            data.get("company_phone", ""),
        ]
        to_lines = [
            data["client_name"],
            data["client_address"],
            data["client_email"],
        ]

        from_block = _block("FROM", [l for l in from_lines if l])
        to_block = _block("BILL TO", [l for l in to_lines if l])

        label_bg = TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), PRIMARY),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [LIGHT_BG, WHITE]),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("BOX", (0, 0), (-1, -1), 0.5, BORDER_GRAY),
        ])

        col_w = (content_width - 8 * mm) / 2

        from_tbl = Table([[p] for p in from_block], colWidths=[col_w])
        from_tbl.setStyle(label_bg)

        to_tbl = Table([[p] for p in to_block], colWidths=[col_w])
        to_tbl.setStyle(label_bg)

        outer = Table([[from_tbl, Spacer(8 * mm, 1), to_tbl]],
                      colWidths=[col_w, 8 * mm, col_w])
        outer.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return [outer]

    def _items_table(self, data: dict) -> list:
        sym = data.get("currency_symbol", "$")
        content_width = PAGE_W - 2 * MARGIN

        header = ["#", "Description", "Qty", "Unit Price", "Amount"]
        col_widths = [
            10 * mm,
            content_width - 10 * mm - 18 * mm - 26 * mm - 26 * mm,
            18 * mm,
            26 * mm,
            26 * mm,
        ]

        header_style = ParagraphStyle("TH", fontSize=9, fontName="Helvetica-Bold",
                                      textColor=WHITE, alignment=TA_CENTER)
        cell_style = ParagraphStyle("TD", fontSize=9, textColor=GRAY_TEXT,
                                    alignment=TA_LEFT, leading=12)
        num_style = ParagraphStyle("TDNum", fontSize=9, textColor=GRAY_TEXT,
                                   alignment=TA_RIGHT, leading=12)

        rows = [[Paragraph(h, header_style) for h in header]]

        for idx, item in enumerate(data["items"], start=1):
            qty = float(item["quantity"])
            price = float(item["unit_price"])
            amount = qty * price
            rows.append([
                Paragraph(str(idx), ParagraphStyle("TDC", fontSize=9,
                           textColor=GRAY_TEXT, alignment=TA_CENTER)),
                Paragraph(str(item["description"]), cell_style),
                Paragraph(str(int(qty) if qty == int(qty) else qty), num_style),
                Paragraph(_money(price, sym), num_style),
                Paragraph(_money(amount, sym), num_style),
            ])

        tbl = Table(rows, colWidths=col_widths, repeatRows=1)
        tbl.setStyle(TableStyle([
            # Header row
            ("BACKGROUND", (0, 0), (-1, 0), PRIMARY),
            ("ROWBACKGROUNDS", (1, 0), (-1, -1), [LIGHT_BG, WHITE]),
            ("GRID", (0, 0), (-1, -1), 0.4, BORDER_GRAY),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        return [tbl]

    def _totals_section(self, data: dict) -> list:
        sym = data.get("currency_symbol", "$")
        content_width = PAGE_W - 2 * MARGIN

        subtotal = sum(
            float(i["quantity"]) * float(i["unit_price"]) for i in data["items"]
        )
        tax_rate = float(data.get("tax_rate", 0))
        tax_amount = subtotal * tax_rate
        total = subtotal + tax_amount

        label_s = ParagraphStyle("TotLabel", fontSize=9, textColor=GRAY_TEXT,
                                 alignment=TA_RIGHT, fontName="Helvetica-Bold")
        value_s = ParagraphStyle("TotValue", fontSize=9, textColor=GRAY_TEXT,
                                 alignment=TA_RIGHT)
        total_label_s = ParagraphStyle("GrandLabel", fontSize=11, textColor=WHITE,
                                       alignment=TA_RIGHT, fontName="Helvetica-Bold")
        total_value_s = ParagraphStyle("GrandVal", fontSize=11, textColor=WHITE,
                                       alignment=TA_RIGHT, fontName="Helvetica-Bold")

        rows = [
            [Paragraph("Subtotal:", label_s), Paragraph(_money(subtotal, sym), value_s)],
            [Paragraph(f"Tax ({tax_rate*100:.0f}%):", label_s),
             Paragraph(_money(tax_amount, sym), value_s)],
            [Paragraph("TOTAL:", total_label_s),
             Paragraph(_money(total, sym), total_value_s)],
        ]

        col_w = 50 * mm
        tbl = Table(rows, colWidths=[col_w, col_w])
        tbl.setStyle(TableStyle([
            ("ROWBACKGROUNDS", (0, 0), (-1, 1), [WHITE, LIGHT_BG]),
            ("BACKGROUND", (0, 2), (-1, 2), PRIMARY),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("BOX", (0, 0), (-1, -1), 0.5, BORDER_GRAY),
            ("LINEABOVE", (0, 2), (-1, 2), 1, PRIMARY),
        ]))

        # Right-align the totals block
        wrapper = Table(
            [[Spacer(content_width - 100 * mm, 1), tbl]],
            colWidths=[content_width - 100 * mm, 100 * mm],
        )
        wrapper.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return [wrapper]

    def _notes_section(self, notes: str) -> list:
        style = ParagraphStyle("Notes", fontSize=8, textColor=GRAY_TEXT,
                               leading=12, borderPad=6,
                               borderColor=BORDER_GRAY, borderWidth=0.5,
                               backColor=LIGHT_BG, leftIndent=6, rightIndent=6)
        return [
            Paragraph("<b>Notes</b>", ParagraphStyle("NoteHead", fontSize=9,
                       fontName="Helvetica-Bold", textColor=PRIMARY)),
            Spacer(1, 2 * mm),
            Paragraph(notes, style),
        ]

    def _footer_section(self, data: dict) -> list:
        style = ParagraphStyle("Footer", fontSize=7, textColor=GRAY_TEXT,
                               alignment=TA_CENTER)
        return [
            Spacer(1, 10 * mm),
            HRFlowable(width="100%", thickness=0.5, color=BORDER_GRAY),
            Spacer(1, 2 * mm),
            Paragraph(
                f"Thank you for your business — {data['company_name']} · "
                f"{data['company_email']}",
                style,
            ),
        ]
