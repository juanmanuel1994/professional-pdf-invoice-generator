"""
Demo: generate sample invoices from dict data and from CSV files.
Run:  python demo.py
Output PDFs land in the ./output/ folder.
"""

from invoice_generator import InvoiceGenerator

gen = InvoiceGenerator(output_dir="output")

# ---------------------------------------------------------------------------
# 1. Single invoice from a Python dict
# ---------------------------------------------------------------------------

single_invoice = {
    "company_name": "Acme Solutions LLC",
    "company_address": "123 Business Ave, Suite 400, New York, NY 10001",
    "company_email": "billing@acmesolutions.com",
    "company_phone": "+1 (212) 555-0100",
    "client_name": "Globex Corporation",
    "client_address": "742 Evergreen Terrace, Springfield, IL 62701",
    "client_email": "accounts@globexcorp.com",
    "invoice_date": "2026-06-10",
    "due_date": "2026-07-10",
    "tax_rate": 0.08,           # 8%
    "currency_symbol": "$",
    "notes": (
        "Payment due within 30 days. Please include the invoice number on your "
        "bank transfer. Late payments may incur a 1.5% monthly fee."
    ),
    "items": [
        {"description": "Web Application Development (80 hrs @ $95/hr)", "quantity": 1, "unit_price": 7600.00},
        {"description": "UI/UX Design — Dashboard & Mobile Views",        "quantity": 1, "unit_price": 2400.00},
        {"description": "Cloud Infrastructure Setup (AWS)",                "quantity": 1, "unit_price": 850.00},
        {"description": "API Integration — Stripe Payment Gateway",        "quantity": 1, "unit_price": 1200.00},
        {"description": "QA & Testing",                                    "quantity": 8, "unit_price": 120.00},
        {"description": "Monthly Maintenance License",                     "quantity": 3, "unit_price": 299.00},
    ],
}

path = gen.generate(single_invoice)
print(f"[1/3] Single invoice (dict)  -> {path}")

# ---------------------------------------------------------------------------
# 2. Batch from dict list (three invoices, auto-numbered)
# ---------------------------------------------------------------------------

batch_invoices = [
    {
        "company_name": "Pixel & Code Studio",
        "company_address": "88 Creative Blvd, Austin, TX 78701",
        "company_email": "hello@pixelandcode.io",
        "company_phone": "+1 (512) 555-0222",
        "client_name": "Initech Inc.",
        "client_address": "1 Corporate Plaza, Dallas, TX 75201",
        "client_email": "finance@initech.com",
        "invoice_date": "2026-06-01",
        "due_date": "2026-06-30",
        "tax_rate": 0.10,
        "currency_symbol": "$",
        "notes": "Net 30 payment terms.",
        "items": [
            {"description": "Brand Identity Package",   "quantity": 1, "unit_price": 3500.00},
            {"description": "Logo Variations (3 sets)", "quantity": 3, "unit_price": 400.00},
            {"description": "Style Guide Document",     "quantity": 1, "unit_price": 750.00},
        ],
    },
    {
        "company_name": "DataStream Analytics",
        "company_address": "200 Data Center Dr, Seattle, WA 98101",
        "company_email": "invoices@datastream.ai",
        "company_phone": "+1 (206) 555-0333",
        "client_name": "Oceanic Airlines",
        "client_address": "LAX Terminal B, Los Angeles, CA 90045",
        "client_email": "procurement@oceanic.com",
        "invoice_date": "2026-06-05",
        "due_date": "2026-07-05",
        "tax_rate": 0.0,   # tax-exempt client
        "currency_symbol": "$",
        "notes": "Tax-exempt order #OA-2026-0089. No sales tax applied.",
        "items": [
            {"description": "Data Pipeline Architecture Consulting", "quantity": 20, "unit_price": 225.00},
            {"description": "ETL Development — Flight Data Ingestion", "quantity": 1, "unit_price": 8500.00},
            {"description": "Real-time Dashboard (Power BI)",          "quantity": 1, "unit_price": 3200.00},
            {"description": "Training Session (2 days on-site)",       "quantity": 2, "unit_price": 1800.00},
        ],
    },
    {
        "company_name": "SwiftDev Agency",
        "company_address": "9 Startup Lane, San Francisco, CA 94107",
        "company_email": "billing@swiftdev.co",
        "company_phone": "+1 (415) 555-0444",
        "client_name": "Umbrella Corp",
        "client_address": "1407 Grayskull Rd, Raccoon City, MO 63101",
        "client_email": "ap@umbrella.com",
        "invoice_date": "2026-06-08",
        "due_date": "2026-07-08",
        "tax_rate": 0.07,
        "currency_symbol": "$",
        "notes": "Project phase 2 of 3. Final deliverables pending client sign-off.",
        "items": [
            {"description": "Mobile App — iOS & Android (React Native)", "quantity": 1, "unit_price": 14000.00},
            {"description": "Push Notification Service Integration",      "quantity": 1, "unit_price": 900.00},
            {"description": "App Store Submission Support",               "quantity": 2, "unit_price": 350.00},
        ],
    },
]

paths = gen.generate_batch_from_dicts(batch_invoices)
for i, p in enumerate(paths, start=2):
    print(f"[{i}/4] Batch invoice (dict)     -> {p}")

# ---------------------------------------------------------------------------
# 3. Batch from CSV files
# ---------------------------------------------------------------------------

csv_paths = gen.generate_batch_from_csv(
    csv_path="sample_data/invoices.csv",
    items_csv_path="sample_data/invoice_items.csv",
)
for i, p in enumerate(csv_paths, start=len(paths) + 2):
    print(f"[{i}/?] CSV invoice              -> {p}")

print("\nAll invoices generated successfully. Check the 'output/' folder.")
