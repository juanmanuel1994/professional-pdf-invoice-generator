"""
Interactive TUI menu for the PDF Invoice Generator.
Run:  python menu.py
"""

import os
import sys
import time
from pathlib import Path

# Force UTF-8 on Windows so rich can render box-drawing chars
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

from rich import box
from rich.align import Align
from rich.columns import Columns
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.prompt import Confirm, Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

# ---------------------------------------------------------------------------
# Theme & console
# ---------------------------------------------------------------------------

THEME = Theme({
    "primary":   "bold #7C3AED",
    "secondary": "bold #A78BFA",
    "accent":    "#F59E0B",
    "success":   "bold #10B981",
    "danger":    "bold #EF4444",
    "muted":     "#6B7280",
    "highlight": "bold #F9FAFB on #7C3AED",
    "border":    "#7C3AED",
})

console = Console(theme=THEME, highlight=False, force_terminal=True)

BANNER = r"""
  ___                 _
 |_ _|_ ___ ___  ___(_)__ ___
  | || ' \ V / || / _| / _/ -_)
 |___|_||_\_/ \_,_\__|_\__\___|
   ___                       _
  / __|___ _ _  ___ _ _ __ _| |_ ___ _ _
 | (_ / -_) ' \/ -_) '_/ _` |  _/ _ \ '_|
  \___\___|_||_\___|_| \__,_|\__\___/_|
"""

# ---------------------------------------------------------------------------
# Animations
# ---------------------------------------------------------------------------

def splash_screen():
    console.clear()
    lines = BANNER.strip("\n").split("\n")

    with Live(console=console, refresh_per_second=30) as live:
        rendered = []
        palette = ["#7C3AED", "#8B5CF6", "#A78BFA", "#C4B5FD", "#DDD6FE", "#EDE9FE"]
        for line in lines:
            rendered.append(line)
            gradient = Text()
            for i, l in enumerate(rendered):
                gradient.append(l + "\n", style=palette[min(i, len(palette) - 1)])
            live.update(Align.center(gradient))
            time.sleep(0.07)

    subtitle = Text("  Professional PDF Invoice Generator  ", style="bold #F9FAFB on #7C3AED")
    version  = Text("  v1.0.0  *  Powered by ReportLab  ", style="dim #A78BFA")
    console.print(Align.center(subtitle))
    console.print(Align.center(version))
    console.print()

    with Progress(
        SpinnerColumn(spinner_name="dots2", style="primary"),
        TextColumn("[secondary]Initializing engine...[/secondary]"),
        BarColumn(bar_width=40, style="#7C3AED", complete_style="#A78BFA", finished_style="#10B981"),
        TaskProgressColumn(style="accent"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("boot", total=100)
        steps = [
            (20, "Loading templates..."),
            (40, "Checking output folder..."),
            (60, "Scanning existing invoices..."),
            (85, "Warming up ReportLab..."),
            (100, "Ready!"),
        ]
        current = 0
        for target, label in steps:
            progress.update(task, description=f"[secondary]{label}[/secondary]")
            while current < target:
                time.sleep(0.018)
                current += 1
                progress.update(task, completed=current)

    console.print()


def loading_spinner(message: str, duration: float = 1.0):
    with Progress(
        SpinnerColumn(spinner_name="dots", style="#A78BFA"),
        TextColumn(f"[secondary]{message}[/secondary]"),
        transient=True,
        console=console,
    ) as p:
        p.add_task("", total=None)
        time.sleep(duration)


def generation_progress(label: str, items: int):
    with Progress(
        SpinnerColumn(spinner_name="dots10", style="primary"),
        TextColumn("[secondary]{task.description}[/secondary]"),
        BarColumn(bar_width=45, style="#4C1D95", complete_style="#7C3AED", finished_style="#10B981"),
        TaskProgressColumn(style="accent"),
        console=console,
    ) as progress:
        task = progress.add_task(label, total=items)
        for _ in range(items):
            time.sleep(0.4)
            progress.advance(task)


# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------

def clear():
    console.clear()


def header():
    console.print(Rule(style="border"))
    title = Text("Invoice Generator", style="primary")
    title.append("  >>  ", style="accent")
    title.append("Menu", style="secondary")
    console.print(Align.center(title))
    console.print(Rule(style="border"))
    console.print()


def success(msg: str):
    console.print(f"\n  [success][OK]  {msg}[/success]\n")


def error(msg: str):
    console.print(f"\n  [danger][ERR] {msg}[/danger]\n")


def info(msg: str):
    console.print(f"  [muted]{msg}[/muted]")


def pause():
    console.print()
    Prompt.ask("  [muted]Press Enter to return to menu[/muted]", default="", console=console)


def build_menu_table() -> Table:
    tbl = Table(
        box=box.ROUNDED,
        border_style="border",
        show_header=False,
        padding=(0, 2),
        expand=False,
        min_width=60,
    )
    tbl.add_column("key",   style="highlight",  width=5,  justify="center")
    tbl.add_column("label", style="secondary",  width=28)
    tbl.add_column("desc",  style="muted",      width=30)

    options = [
        ("1", "Quick Demo",             "Generate 6 sample invoices"),
        ("2", "Single Invoice (dict)",  "Fill fields interactively"),
        ("3", "Batch from Dict List",   "3-invoice demo batch"),
        ("4", "Batch from CSV",         "Use sample_data/ CSVs"),
        ("5", "View Output Folder",     "List generated PDFs"),
        ("6", "Clear Output Folder",    "Delete all PDFs"),
        ("0", "Exit",                   "Quit the program"),
    ]

    for key, label, desc in options:
        tbl.add_row(key, label, desc)

    return tbl


def stats_panel() -> Panel:
    output_dir = Path("output")
    pdfs = list(output_dir.glob("*.pdf")) if output_dir.exists() else []
    total_size = sum(p.stat().st_size for p in pdfs) / 1024

    grid = Table.grid(padding=(0, 3))
    grid.add_column(style="muted",    justify="right")
    grid.add_column(style="secondary")
    grid.add_row("PDFs generated:", f"[accent]{len(pdfs)}[/accent]")
    grid.add_row("Total size:",     f"[accent]{total_size:.1f} KB[/accent]")
    grid.add_row("Output folder:",  "[accent]output/[/accent]")

    return Panel(grid, title="[primary]Stats[/primary]", border_style="border",
                 padding=(0, 2))


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

def action_quick_demo():
    clear(); header()
    console.print("  [secondary]Running full demo (6 invoices)...[/secondary]\n")
    generation_progress("Generating demo invoices", 6)

    from invoice_generator import InvoiceGenerator
    from demo import single_invoice, batch_invoices

    gen = InvoiceGenerator(output_dir="output")
    paths = [gen.generate(single_invoice)] + gen.generate_batch_from_dicts(batch_invoices)
    csv_paths = gen.generate_batch_from_csv(
        "sample_data/invoices.csv", "sample_data/invoice_items.csv"
    )
    all_paths = paths + csv_paths

    tbl = Table(box=box.SIMPLE, border_style="border", show_header=True,
                header_style="primary", padding=(0, 2))
    tbl.add_column("#",    width=4,  justify="right", style="muted")
    tbl.add_column("File", width=26, style="secondary")
    tbl.add_column("Size", width=10, justify="right", style="accent")

    for i, p in enumerate(all_paths, 1):
        size = Path(p).stat().st_size / 1024
        tbl.add_row(str(i), Path(p).name, f"{size:.1f} KB")

    console.print(Align.center(tbl))
    success(f"{len(all_paths)} invoices written to output/")
    pause()


def action_single_interactive():
    clear(); header()
    console.print("  [secondary]Fill in the invoice details:[/secondary]\n")

    def ask(label, default=""):
        return Prompt.ask(f"  [muted]{label}[/muted]", default=default, console=console)

    company_name    = ask("Company name",           "Acme Solutions LLC")
    company_address = ask("Company address",        "123 Business Ave, New York, NY 10001")
    company_email   = ask("Company email",          "billing@acme.com")
    company_phone   = ask("Company phone",          "+1 (212) 555-0100")
    console.print()
    client_name     = ask("Client name",            "Globex Corporation")
    client_address  = ask("Client address",         "742 Evergreen Terrace, Springfield, IL")
    client_email    = ask("Client email",           "accounts@globex.com")
    console.print()
    invoice_date    = ask("Invoice date (YYYY-MM-DD)", "2026-06-10")
    due_date        = ask("Due date    (YYYY-MM-DD)",  "2026-07-10")
    tax_rate_str    = ask("Tax rate (e.g. 0.08=8%)",   "0.08")
    currency        = ask("Currency symbol",            "$")
    notes           = ask("Notes (optional)",           "Net 30. Thank you for your business.")

    console.print()
    console.print("  [secondary]Add line items (leave description blank to finish):[/secondary]\n")
    items = []
    idx = 1
    while True:
        desc = ask(f"  Item {idx} description")
        if not desc:
            break
        qty   = ask(f"  Item {idx} quantity",   "1")
        price = ask(f"  Item {idx} unit price", "100.00")
        items.append({"description": desc, "quantity": float(qty), "unit_price": float(price)})
        idx += 1
        console.print()

    if not items:
        error("No items added. Invoice cancelled.")
        pause(); return

    data = {
        "company_name":    company_name,    "company_address": company_address,
        "company_email":   company_email,   "company_phone":   company_phone,
        "client_name":     client_name,     "client_address":  client_address,
        "client_email":    client_email,    "invoice_date":    invoice_date,
        "due_date":        due_date,        "tax_rate":        float(tax_rate_str),
        "currency_symbol": currency,        "notes":           notes,
        "items":           items,
    }

    console.print()
    generation_progress("Building PDF", 1)

    from invoice_generator import InvoiceGenerator
    gen  = InvoiceGenerator(output_dir="output")
    path = gen.generate(data)
    success(f"Invoice saved: {path}")
    pause()


def action_batch_dict():
    clear(); header()
    console.print("  [secondary]Generating 3-invoice batch from built-in demo data...[/secondary]\n")
    generation_progress("Generating batch", 3)

    from invoice_generator import InvoiceGenerator
    from demo import batch_invoices

    gen   = InvoiceGenerator(output_dir="output")
    paths = gen.generate_batch_from_dicts(batch_invoices)

    tbl = Table(box=box.SIMPLE, border_style="border", show_header=True,
                header_style="primary", padding=(0, 2))
    tbl.add_column("#",    width=4,  justify="right", style="muted")
    tbl.add_column("File", width=26, style="secondary")
    tbl.add_column("Size", width=10, justify="right", style="accent")
    for i, p in enumerate(paths, 1):
        tbl.add_row(str(i), Path(p).name, f"{Path(p).stat().st_size/1024:.1f} KB")

    console.print(Align.center(tbl))
    success(f"{len(paths)} invoices written to output/")
    pause()


def action_batch_csv():
    clear(); header()
    console.print("  [secondary]Generating invoices from sample_data/ CSVs...[/secondary]\n")

    if not Path("sample_data/invoices.csv").exists():
        error("sample_data/invoices.csv not found.")
        pause(); return

    generation_progress("Reading CSV + building PDFs", 2)

    from invoice_generator import InvoiceGenerator
    gen   = InvoiceGenerator(output_dir="output")
    paths = gen.generate_batch_from_csv(
        "sample_data/invoices.csv", "sample_data/invoice_items.csv"
    )

    tbl = Table(box=box.SIMPLE, border_style="border", show_header=True,
                header_style="primary", padding=(0, 2))
    tbl.add_column("#",    width=4,  justify="right", style="muted")
    tbl.add_column("File", width=26, style="secondary")
    tbl.add_column("Size", width=10, justify="right", style="accent")
    for i, p in enumerate(paths, 1):
        tbl.add_row(str(i), Path(p).name, f"{Path(p).stat().st_size/1024:.1f} KB")

    console.print(Align.center(tbl))
    success(f"{len(paths)} invoices written to output/")
    pause()


def action_view_output():
    clear(); header()
    output_dir = Path("output")
    pdfs = sorted(output_dir.glob("*.pdf")) if output_dir.exists() else []

    if not pdfs:
        info("No PDFs found in output/.")
        pause(); return

    tbl = Table(
        title="[primary]Generated Invoices[/primary]",
        box=box.ROUNDED, border_style="border",
        header_style="primary", padding=(0, 2),
    )
    tbl.add_column("#",        width=5,  justify="right", style="muted")
    tbl.add_column("File",     width=28, style="secondary")
    tbl.add_column("Size",     width=12, justify="right", style="accent")
    tbl.add_column("Modified", width=20, style="muted")

    for i, p in enumerate(pdfs, 1):
        stat  = p.stat()
        size  = stat.st_size / 1024
        mtime = time.strftime("%Y-%m-%d %H:%M", time.localtime(stat.st_mtime))
        tbl.add_row(str(i), p.name, f"{size:.1f} KB", mtime)

    console.print(Align.center(tbl))
    console.print()
    info(f"Total: {len(pdfs)} files  |  Folder: output/")
    pause()


def action_clear_output():
    clear(); header()
    output_dir = Path("output")
    pdfs = list(output_dir.glob("*.pdf")) if output_dir.exists() else []

    if not pdfs:
        info("output/ is already empty.")
        pause(); return

    console.print(f"  [danger]This will delete {len(pdfs)} PDF file(s).[/danger]\n")
    confirm = Confirm.ask("  Are you sure?", console=console, default=False)

    if confirm:
        loading_spinner("Deleting files...", 0.8)
        for p in pdfs:
            p.unlink()
        success(f"Deleted {len(pdfs)} PDF(s) from output/")
    else:
        info("Cancelled.")

    pause()


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

ACTIONS = {
    "1": action_quick_demo,
    "2": action_single_interactive,
    "3": action_batch_dict,
    "4": action_batch_csv,
    "5": action_view_output,
    "6": action_clear_output,
}


def main():
    Path("output").mkdir(exist_ok=True)
    splash_screen()

    while True:
        clear()
        header()

        menu_panel = Panel(
            Align.center(build_menu_table()),
            title="[primary]  Actions  [/primary]",
            border_style="border",
            padding=(1, 2),
        )
        layout = Columns([menu_panel, stats_panel()], equal=False, expand=False)
        console.print(Align.center(layout))
        console.print()

        choice = Prompt.ask(
            "  [primary]>[/primary] [secondary]Select option[/secondary]",
            choices=["0", "1", "2", "3", "4", "5", "6"],
            show_choices=False,
            console=console,
        )

        if choice == "0":
            clear()
            console.print(Align.center(Text("\n  Goodbye! Happy invoicing.\n", style="primary")))
            time.sleep(0.8)
            sys.exit(0)

        action = ACTIONS.get(choice)
        if action:
            loading_spinner("Loading...", 0.6)
            action()


if __name__ == "__main__":
    main()
